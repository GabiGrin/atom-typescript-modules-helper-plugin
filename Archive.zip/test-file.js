
import  from 'lib/typescript-import.coffee'

export default class Bobson
export default interface Jojo ;
