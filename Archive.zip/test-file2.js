
import Test from 'test-file'

import  from 'lib/typescript-import.coffee'

import Test from '..'

import Test from '..'

import Test from './../test-file2.js'
var a = new Test
import Test from '../test-file2.js'();
